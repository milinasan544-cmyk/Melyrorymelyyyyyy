import React, { useEffect, useState } from "react";
import {
  SafeAreaView, View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, StatusBar, Alert
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const BLUE = "#123B69";
const LIGHT = "#EDF3FA";
const DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس"];
const DEFAULT_PROFILE = {
  name: "اسم الطالب", surname: "اللقب", university: "جامعة تيزي وزو",
  specialty: "إعلام آلي", year: "السنة الأولى", studentId: "2026-00001"
};
const DEFAULT_GRADES = [
  { subject: "رياضيات", grade: "15" },
  { subject: "إعلام آلي", grade: "17" },
  { subject: "فيزياء", grade: "13" }
];

export default function App() {
  const [tab, setTab] = useState("card");
  const [profile, setProfile] = useState(DEFAULT_PROFILE);
  const [grades, setGrades] = useState(DEFAULT_GRADES);
  const [day, setDay] = useState("الأحد");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem("campus-app-data");
        if (saved) {
          const data = JSON.parse(saved);
          if (data.profile) setProfile(data.profile);
          if (data.grades) setGrades(data.grades);
        }
      } catch (e) {}
      setLoaded(true);
    })();
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.setItem("campus-app-data", JSON.stringify({ profile, grades })).catch(() => {});
  }, [profile, grades, loaded]);

  const updateProfile = (key, value) => setProfile(p => ({ ...p, [key]: value }));
  const updateGrade = (index, value) => setGrades(items => items.map((g, i) => i === index ? { ...g, grade: value } : g));
  const average = grades.length
    ? (grades.reduce((sum, item) => sum + (Number(item.grade) || 0), 0) / grades.length).toFixed(2)
    : "0.00";

  const schedule = day === "الأحد"
    ? [["08:00 – 09:30", "رياضيات", "محاضرة"], ["10:00 – 11:30", "إعلام آلي", "أعمال تطبيقية"], ["13:00 – 14:30", "فيزياء", "أعمال موجهة"]]
    : [["08:00 – 09:30", "مادة دراسية", "محاضرة"], ["10:00 – 11:30", "أعمال تطبيقية", "TD"]];

  const Field = ({ label, value, onChangeText, placeholder }) => (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder || label}
        textAlign="right"
        placeholderTextColor="#8494A7"
      />
    </View>
  );

  const NavButton = ({ id, label, symbol }) => (
    <TouchableOpacity style={styles.navItem} onPress={() => setTab(id)}>
      <Text style={[styles.navIcon, tab === id && styles.activeText]}>{symbol}</Text>
      <Text style={[styles.navLabel, tab === id && styles.activeText]}>{label}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={BLUE} />
      <View style={styles.header}>
        <View style={styles.brandRow}>
          <Text style={styles.brandIcon}>🎓</Text>
          <View>
            <Text style={styles.brand}>Campus ID</Text>
            <Text style={styles.subtitle}>مساحتك الجامعية الشخصية</Text>
          </View>
        </View>
        <Text style={styles.welcome}>مرحبًا بك 👋</Text>
        <Text style={styles.headerNote}>بطاقتك وجدولك ونتائجك في مكان واحد</Text>
      </View>

      <View style={styles.tabs}>
        {[["card","بطاقتي"],["schedule","الجدول"],["grades","النقاط"],["profile","ملفي"]].map(([id,label]) => (
          <TouchableOpacity key={id} onPress={() => setTab(id)} style={[styles.tab, tab === id && styles.selectedTab]}>
            <Text style={[styles.tabText, tab === id && styles.selectedTabText]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {tab === "card" && (
          <>
            <Text style={styles.sectionTitle}>بطاقتك الشخصية</Text>
            <View style={styles.studentCard}>
              <View style={styles.cardTop}>
                <View>
                  <Text style={styles.cardTitle}>STUDENT PROFILE</Text>
                  <Text style={styles.cardSub}>بطاقة شخصية • غير رسمية</Text>
                </View>
                <Text style={styles.cardCap}>🎓</Text>
              </View>
              <View style={styles.cardDivider} />
              <View style={styles.identityRow}>
                <View style={styles.avatar}><Text style={styles.avatarText}>👤</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.studentName}>{profile.name} {profile.surname}</Text>
                  <Text style={styles.studentMeta}>{profile.specialty}</Text>
                  <Text style={styles.studentMeta}>{profile.year}</Text>
                </View>
              </View>
              <View style={styles.cardDivider} />
              <Text style={styles.cardLabel}>الجامعة</Text>
              <Text style={styles.cardValue}>{profile.university}</Text>
              <View style={styles.cardInfoRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.cardLabel}>رقم تعريفي تجريبي</Text>
                  <Text style={styles.cardValue}>{profile.studentId}</Text>
                </View>
              </View>
              <View style={styles.disclaimer}><Text style={styles.disclaimerText}>للعرض الشخصي فقط — ليست إثبات تسجيل جامعي</Text></View>
            </View>
            <TouchableOpacity style={styles.primaryButton} onPress={() => setTab("profile")}>
              <Text style={styles.primaryButtonText}>✎  تعديل بيانات البطاقة</Text>
            </TouchableOpacity>
          </>
        )}

        {tab === "schedule" && (
          <>
            <Text style={styles.sectionTitle}>جدول الحصص</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.dayScroller}>
              {DAYS.map(d => (
                <TouchableOpacity key={d} onPress={() => setDay(d)} style={[styles.dayPill, day === d && styles.dayPillActive]}>
                  <Text style={[styles.dayText, day === d && styles.dayTextActive]}>{d}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            {schedule.map((item, i) => (
              <View key={i} style={styles.lesson}>
                <View style={styles.lessonIcon}><Text>◷</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.lessonTitle}>{item[1]}</Text>
                  <Text style={styles.lessonSub}>{item[2]}</Text>
                </View>
                <Text style={styles.lessonTime}>{item[0]}</Text>
              </View>
            ))}
            <Text style={styles.hint}>هذه حصص تجريبية. يمكنك استبدالها بجدولك الحقيقي في إصدار لاحق.</Text>
          </>
        )}

        {tab === "grades" && (
          <>
            <Text style={styles.sectionTitle}>النقاط والمعدلات</Text>
            {grades.map((g, i) => (
              <View key={i} style={styles.gradeRow}>
                <Text style={styles.gradeSubject}>{g.subject}</Text>
                <TextInput
                  style={styles.gradeInput}
                  keyboardType="decimal-pad"
                  value={g.grade}
                  onChangeText={v => updateGrade(i, v)}
                  textAlign="center"
                />
                <Text style={styles.gradeOutOf}>/20</Text>
              </View>
            ))}
            <View style={styles.averageBox}>
              <Text style={styles.averageLabel}>المعدل الحسابي التجريبي</Text>
              <Text style={styles.averageValue}>{average} / 20</Text>
            </View>
            <Text style={styles.hint}>عدّلي النقاط مباشرة، وسيُحسب المتوسط تلقائيًا.</Text>
          </>
        )}

        {tab === "profile" && (
          <>
            <Text style={styles.sectionTitle}>إعدادات الملف الشخصي</Text>
            <Field label="الاسم" value={profile.name} onChangeText={v => updateProfile("name", v)} />
            <Field label="اللقب" value={profile.surname} onChangeText={v => updateProfile("surname", v)} />
            <Field label="الجامعة" value={profile.university} onChangeText={v => updateProfile("university", v)} />
            <Field label="التخصص" value={profile.specialty} onChangeText={v => updateProfile("specialty", v)} />
            <Field label="السنة الدراسية" value={profile.year} onChangeText={v => updateProfile("year", v)} />
            <Field label="رقم تعريفي شخصي تجريبي" value={profile.studentId} onChangeText={v => updateProfile("studentId", v)} />
            <TouchableOpacity style={styles.primaryButton} onPress={() => { setTab("card"); Alert.alert("تم الحفظ", "تم حفظ بياناتك على هذا الجهاز."); }}>
              <Text style={styles.primaryButtonText}>حفظ ومعاينة البطاقة</Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>

      <View style={styles.bottomNav}>
        <NavButton id="card" label="البطاقة" symbol="▣" />
        <NavButton id="schedule" label="الجدول" symbol="▦" />
        <NavButton id="grades" label="النقاط" symbol="▤" />
        <NavButton id="profile" label="حسابي" symbol="●" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F6F8FB" },
  header: { backgroundColor: BLUE, paddingHorizontal: 22, paddingTop: 18, paddingBottom: 24, borderBottomLeftRadius: 22, borderBottomRightRadius: 22 },
  brandRow: { flexDirection: "row-reverse", alignItems: "center", gap: 12 },
  brandIcon: { fontSize: 30, backgroundColor: "#FFFFFF22", padding: 9, borderRadius: 12 },
  brand: { color: "white", fontSize: 21, fontWeight: "800", textAlign: "right" },
  subtitle: { color: "#D9E8FA", fontSize: 12, textAlign: "right", marginTop: 2 },
  welcome: { color: "white", fontSize: 25, fontWeight: "800", textAlign: "right", marginTop: 22 },
  headerNote: { color: "#D9E8FA", textAlign: "right", marginTop: 5 },
  tabs: { flexDirection: "row-reverse", backgroundColor: "white", marginHorizontal: 14, marginTop: 14, borderRadius: 13, padding: 4, elevation: 1 },
  tab: { flex: 1, paddingVertical: 11, borderRadius: 10, alignItems: "center" },
  selectedTab: { backgroundColor: BLUE },
  tabText: { color: "#53677D", fontWeight: "600", fontSize: 13 },
  selectedTabText: { color: "white" },
  content: { padding: 18, paddingBottom: 28 },
  sectionTitle: { color: "#183B60", fontSize: 20, fontWeight: "800", textAlign: "right", marginBottom: 15 },
  studentCard: { backgroundColor: LIGHT, borderRadius: 20, padding: 18, borderWidth: 1, borderColor: "#D7E2EE" },
  cardTop: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  cardTitle: { color: BLUE, fontSize: 16, fontWeight: "900", textAlign: "right", letterSpacing: 1 },
  cardSub: { color: "#56718D", textAlign: "right", fontSize: 11, marginTop: 4 },
  cardCap: { fontSize: 27 },
  cardDivider: { height: 1, backgroundColor: "#C9D8E8", marginVertical: 15 },
  identityRow: { flexDirection: "row-reverse", alignItems: "center", gap: 14 },
  avatar: { width: 68, height: 68, backgroundColor: "#D4E1EF", borderRadius: 15, alignItems: "center", justifyContent: "center" },
  avatarText: { fontSize: 31 },
  studentName: { color: "#163C64", fontWeight: "800", fontSize: 17, textAlign: "right" },
  studentMeta: { color: "#526D88", textAlign: "right", marginTop: 4, fontSize: 12 },
  cardLabel: { color: "#617A94", fontSize: 11, textAlign: "right", marginBottom: 4 },
  cardValue: { color: "#183B60", fontSize: 14, fontWeight: "700", textAlign: "right" },
  cardInfoRow: { flexDirection: "row-reverse", marginTop: 14 },
  disclaimer: { backgroundColor: "#DCE8F5", borderRadius: 8, padding: 9, marginTop: 16 },
  disclaimerText: { color: "#31577E", textAlign: "center", fontSize: 10 },
  primaryButton: { backgroundColor: BLUE, padding: 15, borderRadius: 12, alignItems: "center", marginTop: 16 },
  primaryButtonText: { color: "white", fontWeight: "800", fontSize: 14 },
  dayScroller: { marginBottom: 14, maxHeight: 45 },
  dayPill: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, backgroundColor: "#E8EEF5", marginLeft: 8 },
  dayPillActive: { backgroundColor: BLUE },
  dayText: { color: "#36536F", fontWeight: "600" },
  dayTextActive: { color: "white" },
  lesson: { backgroundColor: "white", borderRadius: 13, padding: 14, marginBottom: 10, flexDirection: "row-reverse", alignItems: "center", gap: 12, borderWidth: 1, borderColor: "#E7EDF3" },
  lessonIcon: { width: 38, height: 38, backgroundColor: LIGHT, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  lessonTitle: { color: "#183B60", textAlign: "right", fontWeight: "800" },
  lessonSub: { color: "#73869A", textAlign: "right", fontSize: 11, marginTop: 4 },
  lessonTime: { color: "#31577E", fontWeight: "700", fontSize: 11 },
  hint: { color: "#7B8998", textAlign: "right", fontSize: 11, marginTop: 12, lineHeight: 18 },
  gradeRow: { flexDirection: "row-reverse", alignItems: "center", backgroundColor: "white", borderRadius: 12, padding: 12, marginBottom: 9, borderWidth: 1, borderColor: "#E7EDF3" },
  gradeSubject: { flex: 1, color: "#183B60", fontWeight: "700", textAlign: "right" },
  gradeInput: { backgroundColor: LIGHT, width: 58, borderRadius: 8, padding: 8, color: BLUE, fontWeight: "800" },
  gradeOutOf: { color: "#6D8093", marginLeft: 7 },
  averageBox: { backgroundColor: LIGHT, padding: 18, borderRadius: 14, marginTop: 8, alignItems: "center" },
  averageLabel: { color: "#56718D", fontSize: 12 },
  averageValue: { color: BLUE, fontSize: 27, fontWeight: "900", marginTop: 5 },
  field: { marginBottom: 13 },
  label: { color: "#36536F", textAlign: "right", fontWeight: "700", marginBottom: 6, fontSize: 13 },
  input: { backgroundColor: "white", borderColor: "#DCE5EE", borderWidth: 1, borderRadius: 10, paddingHorizontal: 13, paddingVertical: 12, color: "#183B60" },
  bottomNav: { flexDirection: "row-reverse", backgroundColor: "white", borderTopWidth: 1, borderTopColor: "#E6ECF2", paddingVertical: 9, paddingHorizontal: 10, justifyContent: "space-around" },
  navItem: { alignItems: "center", minWidth: 58 },
  navIcon: { color: "#73869A", fontSize: 20, fontWeight: "800" },
  navLabel: { color: "#73869A", fontSize: 10, marginTop: 2 },
  activeText: { color: "#2464A0", fontWeight: "900" }
});
